int x;
int y = 5;
float a = 6.2555;
bool u = false;
string s = "abc";
